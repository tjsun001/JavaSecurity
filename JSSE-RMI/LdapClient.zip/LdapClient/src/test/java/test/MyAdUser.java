package test;

public class MyAdUser {
	String userId = null;
	String organizationalGroups = null;
	public MyAdUser(){
	}
	
	public MyAdUser (String userId, String organizationalGroups){
		this.userId = userId;
		this.organizationalGroups = organizationalGroups;		
	}
}
